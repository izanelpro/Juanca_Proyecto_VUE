<template>

    <h1>Página de contacto</h1>
</template>

<script>

export default {
    name: "TablaContacto",
    components: {
        
    }
}
</script>

<style>

</style>