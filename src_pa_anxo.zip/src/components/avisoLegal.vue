<template>

    <h1>Política de Privacidad</h1>
    <h2>Aviso Legal</h2>
    <h3>1. Información General</h3>
    <p>En cumplimiento con lo establecido en la legislación vigente, se informa que el presente sitio web es propiedad
        de Import-Export Teis, S.L., con domicilio en Avenida de Galicia, 36216 Vigo, España, y con CIF B-12345678.
        Puede ponerse en contacto con nosotros a través de:</p>
    <p>Teléfono: +34 986 111 111</p>
    <p>Correo electrónico: info@importexportteis.com</p>
    <br>
    <h3>2. Condiciones de Uso</h3>
    <p>El acceso y uso de este sitio web implica la 
       aceptación de los términos y condiciones 
       establecidos en el presente Aviso Legal. 
       Los usuarios se comprometen a utilizar el 
       sitio web de forma adecuada y lícita.</p>
    <br>
    <h3>3. Propiedad Intelectual e Industrial</h3>
    <p>Todos los contenidos de este sitio web, 
        incluidos textos, imágenes, logotipos, diseños,
        software, y cualquier otro material, son 
        propiedad de Import-Export Teis, S.L. o de 
        terceros que han autorizado su uso. Queda 
        prohibida su reproducción, distribución, 
        comunicación pública o transformación sin 
        autorización previa y por escrito de los 
        titulares.
    </p>
    <br>
    <h3>4. Protección de Datos Personales</h3>
    <p>De acuerdo con el Reglamento General de 
        Protección de Datos (RGPD), le informamos 
        de que los datos personales que nos facilite 
        serán tratados por Import-Export Teis, S.L. 
        con la finalidad de gestionar las consultas 
        realizadas a través de este sitio web.
        Para más información, consulte nuestra 
        Política de Privacidad.</p>
    <br>
    <h3>5. Exención de Responsabilidad</h3>
    <p>Import-Export Teis, S.L. no será responsable 
        de los daños y perjuicios que puedan derivarse 
        del uso incorrecto de los contenidos del sitio 
        web, ni de posibles errores técnicos o 
        interrupciones en el servicio.</p>
    <br>
    <h3>6. Legislación Aplicable y Jurisdicción</h3>
    <p>El presente Aviso Legal se rige por la 
        legislación española. Para cualquier 
        controversia que pueda surgir, ambas partes se 
        someterán a los juzgados y tribunales de Vigo.</p>
    <br>
    <br>
    <h2>Política de Privacidad</h2>
    <h3>1. Responsable del Tratamiento</h3>
    <p>El responsable del tratamiento de sus datos personales es Import-Export Teis, S.L., con domicilio en Avenida de Galicia, 101 , 45, 36216 Vigo, España, y CIF B-12345678.
        Puede ponerse en contacto con nosotros a través de:</p>
    <li>Correo electrónico: info@importexportteis.com</li>
    <li>Teléfono: +34 986 111 111</li>
    <br>
    <h3>2. Datos que Recogemos</h3>
    <p>Recopilamos datos personales que usted nos 
        proporciona directamente al utilizar nuestro 
        sitio web o nuestros servicios. Estos datos incluyen:</p>
    <li>Información de contacto: nombre, correo electrónico, teléfono.</li>
    <li>Datos necesarios para realizar transacciones o pedidos: dirección, detalles de pago.</li>
    <li>Información adicional que nos facilite voluntariamente a través de formularios o correos electrónicos.</li>
    <br>
    <h3>3. Finalidad del Tratamiento</h3>
    <p>Tratamos los datos personales para las siguientes finalidades:
    </p>
    <li>Responder a consultas realizadas a través del sitio web.</li>
    <li>Gestionar pedidos y envíos de productos o servicios.</li>
    <li>Enviar comunicaciones comerciales relacionadas con nuestros productos o servicios, previo consentimiento expreso.</li>
    <li>Cumplir con obligaciones legales.</li>
    <br>
    <h3>4. Base Jurídica del Tratamiento</h3>
    <p>El tratamiento de sus datos personales se basa en:</p>
    <li>Su consentimiento para el envío de formularios de contacto o suscripción.</li>
    <li>La ejecución de un contrato en caso de pedidos.</li>
    <li>El cumplimiento de obligaciones legales.</li>
    <br>
    <h3>5. Destinatarios de los Datos</h3>
    <p>Sus datos personales no serán compartidos con terceros, 
        excepto en los casos necesarios para cumplir con 
        una obligación legal o para ejecutar un contrato 
        (por ejemplo, servicios de transporte).</p>
    <br>
    <h3>6. Conservación de los Datos</h3>
    <p>Conservaremos sus datos personales mientras 
        sean necesarios para cumplir con las 
        finalidades descritas. Cuando ya no sean 
        necesarios, se eliminarán de forma segura.</p>
    <br>
    <h3>7. Derechos del Usuario</h3>
    <p>Usted tiene derecho a:</p>
    <li>Acceder a sus datos personales.</li>
    <li>Rectificar datos inexactos o incompletos.</li>
    <li>Solicitar la supresión de sus datos cuando ya no sean necesarios.</li>
    <li>Limitar el tratamiento de sus datos en determinadas circunstancias.</li>
    <li>Oponerse al tratamiento de sus datos para fines específicos.</li>
    <li>Solicitar la portabilidad de sus datos.</li>
    <p>Para ejercer estos derechos, puede enviar una 
        solicitud a info@importexportteis.com, 
        adjuntando una copia de su documento de identidad.</p>
    <br>
    <h3>8. Seguridad de los Datos</h3>
    <p>Implementamos medidas técnicas y organizativas para 
        garantizar la seguridad de sus datos personales y 
        protegerlos frente a accesos no autorizados, pérdida o destrucción.</p>
    <br>
    <h3>9. Cambios en la Política de Privacidad</h3>
    <p>Nos reservamos el derecho a actualizar esta 
        Política de Privacidad en cualquier momento. 
        La fecha de la última modificación se indicará 
        al final del documento.</p>
    <br>
    <h3>10. Contacto</h3>
    <p>Si tiene alguna pregunta o desea más información
        sobre nuestra Política de Privacidad, no dude 
        en contactarnos en info@importexportteis.com.</p>
    <p>Fecha de última actualización:12/09/2024</p>

</template>

<script>

export default {
    name: "avisoLegal",
    components: {

    }
}
</script>

<style></style>