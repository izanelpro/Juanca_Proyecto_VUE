<template>
    <footer class="bg-primary text-white text-center py-1">
        <div class="container">
            <p>© 2024 Mi Empresa. Todos los derechos reservados.
                <a href="/avisos-legales" class="nav-link d-inline text-white">Aviso Legal</a> |
                <a href="/privacidad" class="nav-link d-inline text-white">Política de Privacidad</a>
            </p>
        </div>
    </footer>
</template>

<script>
export default {
    name: "AppFooter"
};
</script>

<style scoped>
footer {
    width: 100%;
}
</style>