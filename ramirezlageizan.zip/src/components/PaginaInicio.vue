<template>

    <h1>Página de inicio</h1>
</template>

<script>

export default {
    name: "PaginaInicio",
    components: {
        
    }
}
</script>

<style>

</style>